sap.ui.define([
		"com/amadeus/fiori/ppm/commons/util/CommonFormatter",
		"sap/ui/core/format/DateFormat"
	], function (CommonFormatter, DateFormat) {
	
	"use strict";

	return {	


	};

});
