sap.ui.define([
		"com/amadeus/fiori/ppm/commons/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("com.amadeus.fiori.iaos.creation.ycrc.controller.App", {

			onInit : function () {
				// Nothing to do
				
			}
		});

	}
);